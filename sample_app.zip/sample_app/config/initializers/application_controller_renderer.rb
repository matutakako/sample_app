# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '926847d98dc0e23a108d9ccf4170f34b0c4fee0b8badd36ef5b274ccae9ee7b870bfd594ff2babc69733a81c4f2886d012660dae653d49bc779c140759eaedff'